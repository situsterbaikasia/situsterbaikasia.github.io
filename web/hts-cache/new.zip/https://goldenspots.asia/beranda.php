<!DOCTYPE html>
<html lang="en">


    <head  >

    <meta name="viewport" content="width=device-width, initial-scale=1.0">



        
    <title> Situs terbaik di IND-Golden's JP </title>
        
    <link rel="apple-touch-icon" sizes="180x180" href="favicon_io/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="favicon_io/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="favicon_io/favicon-16x16.png">
        <link rel="manifest" href="favicon_io/site.webmanifest">

        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

        
        
        
        
        
        
        <link align="left" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="style5.css">
        <input  type="checkbox" id="tag-menu"/>
         <label class="fa fa-bars menu-bar" for="tag-menu"></label>
  <div class="jw-drawer">
    <nav>
      <ul>
        <li><a onclick='javascript:alert("Beranda *Silahkan Login Terlebih Dahulu*")' href="#"><i class="-"></i>&nbsp;&nbsp;PROFILE</a></li>
        <li><a onclick='javascript:alert("Beranda *Silahkan Login Terlebih Dahulu*")' href="#"><i class="-"></i>&nbsp;&nbsp;DEPOSIT</a></li>
        <li><a onclick='javascript:alert("Beranda *Silahkan Login Terlebih Dahulu*")' href="#"><i class="-"></i>&nbsp;&nbsp;WITHDRAW</a></li>
        <li><a onclick='javascript:alert("Beranda *Silahkan Login Terlebih Dahulu*")' href="#"><i class="-"></i>&nbsp;&nbsp;TRANSAKSI</a></li>
        <li><a onclick='javascript:alert("Beranda *Silahkan Login Terlebih Dahulu*")' href="index.php"><i class="-"></i>&nbsp;&nbsp;GOLDEN'S JP</a></li>
      </ul>
    </nav>
  </div>

<blink> <img align="right" src="marquee.jpeg"    width="65%" height="65%"> </blink>

    

<style>
img {
    max-width: 100%;
    height: auto;
}
</style>
    
      </head>
	
<body style="background-color:black" >


<style>
        blink {
          -webkit-animation: 2s linear infinite kedip; /* for Safari 4.0 - 8.0 */
          animation: 2s linear infinite kedip;
        }
        /* for Safari 4.0 - 8.0 */
        @-webkit-keyframes kedip { 
          0% {
            visibility: hidden;
          }
          50% {
            visibility: hidden;
          }
          100% {
            visibility: visible;
          }
        }
        @keyframes kedip {
          0% {
            visibility: hidden;
          }
          50% {
            visibility: hidden;
          }
          100% {
            visibility: visible;
          }
        }</style>




<form  align="right" action="login_submit.php" method="post">
                
                
                
                <a href="#"> <img align="left" src="logoindex.jpeg" width="200" height="200"> </a>
                <a href="https://wa.me/6281311812401"> <img align="right" src="lc.gif" width="100" >   
                <a  href="index.php" <button style="background-color:black"> <img src="login.gif" style="width: 100px;border-radius: 10px;"   >   </a> 
                <a  href="register.php" <button style="background-color:black"> <img src="daftar.gif"  style="width: 100px;border-radius: 10px;" > </a>
              </a>
</form>
            </body>







<body style="background-color:black" align="center">









      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="8"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="9"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="10"></li>


  </ol>
  <div class="carousel-inner">
  <div class="carousel-item active">
      <img src="promo/1.jpg"  class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/2.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/3.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/4.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/5.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/6.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/7.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/8.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/9.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/10.jpg" class="d-block w-100" alt="gambar">
    </div>
    <div class="carousel-item">
      <img src="promo/11.jpg" class="d-block w-100" alt="gambar">
    </div>

  </div>

  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>


  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</body>







<body align="middle" >


<hr color="white">





<style type="text/css">
  img{
   border-radius: 10px;
   margin: 1px;
  }
 </style>


<body >

<center>

<button style="width: 50px;border-radius: 10px;" onclick='javascript:alert("Beranda *Silahkan Login Terlebih Dahulu*")' > <img src="menu/beranda.jpeg" > </button>

<button style="width: 50px;border-radius: 10px;" onclick='javascript:alert("Sabung Ayam *Silahkan Login Terlebih Dahulu*")' > <img src="menu/ayam.jpeg" > </button>

<button style="width: 70px;border-radius: 10px;" onclick='javascript:alert("Casino *Silahkan Login Terlebih Dahulu*")' > <img src="menu/casino.jpeg" > </button>

<button style="width: 54px;border-radius: 10px;" onclick='javascript:alert("Tembak Ikan *Silahkan Login Terlebih Dahulu*")' > <img src="menu/ikan.jpeg" > </button>

<button style="width: 46px;border-radius: 10px;" onclick='javascript:alert("Poker *Silahkan Login Terlebih Dahulu*")' > <img src="menu/poker.jpeg" > </button>

<button style="width: 50px;border-radius: 10px;" onclick='javascript:alert("Slot *Silahkan Login Terlebih Dahulu*")' >  <img src="menu/slot.jpeg"  > </button>

<button style="width: 55px;border-radius: 10px;" onclick='javascript:alert("Sport *Silahkan Login Terlebih Dahulu*")' > <img src="menu/sport.jpeg" > </button>

<button style="width: 45px;border-radius: 10px;" onclick='javascript:alert("Promosi *Silahkan Login Terlebih Dahulu*")' > <img src="menu/promosi.jpeg"  > </button>




<hr color="white">

<img src="pgjp.gif">
<img src="lotto.jpg">
</center>

</body>













     

</body>
</p>




<body >




<figure>
<button style="width: 40px;border-radius: 10px;" onclick='javascript:alert("Slot *Silahkan Login Terlebih Dahulu*")' >  <img src="menu/slot.jpeg"  > </button>
<figcaption style="color:gold;">Slot</figcaption>


<center>
        <img src="logofooter/pp.png" width="20%" height="20%" >
        <img src="logofooter/bng.png" width="20%" height="20%" >
        <img src="logofooter/haba.png" width="20%" height="20%" >
        <img src="logofooter/joker.png" width="20%" height="20%" >
        <img src="logofooter/pg.png" width="20%" height="20%" >
        <img src="logofooter/sp.png" width="20%" height="20%" >
        <img src="logofooter/red.png" width="20%" height="20%" >
        <img src="logofooter/ygg.png" width="20%" height="20%" >
</center>
<center>
<button onclick='javascript:alert("Slot *Silahkan Login Terlebih Dahulu*")' style="background-color:black;" style="border-radius:4px;"><img src="menuslot/1.PNG" width="90%" height="90%"></button>
<button onclick='javascript:alert("Slot *Silahkan Login Terlebih Dahulu*")' style="background-color:black;" style="border-radius:4px;"><img src="menuslot/2.PNG" width="90%" height="90%"></button>
<button onclick='javascript:alert("Slot *Silahkan Login Terlebih Dahulu*")' style="background-color:black;" style="border-radius:4px;"><img src="menuslot/3.PNG" width="90%" height="90%"></button>
<button onclick='javascript:alert("Slot *Silahkan Login Terlebih Dahulu*")' style="background-color:black;" style="border-radius:4px;"><img src="menuslot/4.PNG" width="90%" height="90%"></button>

</center>
<hr color="white">









<button style="width: 45px;border-radius: 10px;" onclick='javascript:alert("Sport *Silahkan Login Terlebih Dahulu*")' > <img src="menu/sport.jpeg" > </button>
<figcaption style="color:gold;">Sport</figcaption>

<button onclick='javascript:alert("Sport *Silahkan Login Terlebih Dahulu*")' style="border-radius:4px;">
<img src="sport1.jpg"> </button>
<center><button onclick='javascript:alert("Sport *Silahkan Login Terlebih Dahulu*")' style="background-color:gold; border-color:red; color:black; border-radius:10%" > Main Sekarang </button>
</center>


<hr color="white">


<button style="width: 50px;border-radius: 10px;" onclick='javascript:alert("Casino *Silahkan Login Terlebih Dahulu*")' > <img src="menu/casino.jpeg" > </button>
<figcaption style="color:gold;">Casino</figcaption>

<center>
<img src="menucasino/1.png" width="15%" height="15%" style="border:3px solid gold;">
<img src="menucasino/2.png"width="15%" height="15%" style="border:3px solid red;"  >
<img src="menucasino/3.png"  width="15%" height="15%" style="border:3px solid green;" >
<img src="menucasino/4.png" width="15%" height="15%" style="border:3px solid blue;" >
<img src="menucasino/5.png" width="15%" height="15%" style="border:3px solid white;" >
<img src="menucasino/6.png" width="15%" height="15%" style="border:3px solid Aqua;" >
<img src="menucasino/7.png" width="15%" height="15%" style="border:3px solid Fuchsia;" >
<img src="menucasino/8.png" width="15%" height="15%" style="border:3px solid Chartreuse;" >
<img src="menucasino/9.png" width="15%" height="15%" style="border:3px solid Cyan;" ></br>
<button onclick='javascript:alert("Casino *Silahkan Login Terlebih Dahulu*")' style="background-color:gold; border-color:red; color:black; border-radius:10%" > Main Sekarang </button>
</center>



<hr color="white">

<button style="width: 44px;border-radius: 10px;" onclick='javascript:alert("Tembak Ikan *Silahkan Login Terlebih Dahulu*")' > <img src="menu/ikan.jpeg" > </button>
<figcaption style="color:gold;">Fishing</figcaption>
<center><img src="tembakikan.PNG" ></br>
<button onclick='javascript:alert("Tembak Ikan *Silahkan Login Terlebih Dahulu*")' style="background-color:gold; border-color:red; color:black; border-radius:10%" > Main Sekarang </button>
</center>

<hr color="white">


<button style="width: 40px;border-radius: 10px;" onclick='javascript:alert("Poker *Silahkan Login Terlebih Dahulu*")' > <img src="menu/poker.jpeg" > </button>
<figcaption style="color:gold;">Poker</figcaption>
<center>
<img src="menupoker/1.PNG">
<img src="menupoker/2.PNG">
<img src="menupoker/3.PNG">
<img src="menupoker/4.PNG"></br>
<button onclick='javascript:alert("Poker *Silahkan Login Terlebih Dahulu*")' style="background-color:gold; border-color:red; color:black; border-radius:10%" > Main Sekarang </button>
</center>



</figure>

</body>
</br>








































<style>
* {box-sizing:border-box}
body {font-family: Verdana,sans-serif;}
.mySlides {display:none}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
</head>




<body>


<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="slide1.jpg" style="width:100%">
  <div class="text">Goldens</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="slide2.png" style="width:100%">
  <div class="text">Goldens</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="slide3.png" style="width:100%">
  <div class="text">Goldens</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>

</body>































































<body>
  <center>
    <p> 
    <img src="logofooter/pp.png" width="15%" height="15%" >
    <img src="logofooter/bng.png" width="15%" height="15%" >
    <img src="logofooter/haba.png" width="15%" height="15%" >
    <img src="logofooter/joker.png" width="15%" height="15%" >
    <img src="logofooter/pg.png" width="15%" height="15%" >
    <img src="logofooter/sp.png" width="15%" height="15%" >
    <img src="logofooter/red.png" width="15%" height="15%" >
    <img src="logofooter/ygg.png" width="15%" height="15%" >
    </p>
</center>
    
    <center>
    <p >
        <img src="logobank/bca.png" width="10%" height="10%" >
        <img src="logobank/bni.png" width="10%" height="10%" >
        <img src="logobank/bri.png" width="10%" height="10%" >
        <img src="logobank/cimb.png" width="15%" height="15%" >
        <img src="logobank/mandiri.png" width="10%" height="10%" >
    </p>
    <p>
        <img src="aman/BMM.png" width="10%" height="10%" >
        <img src="aman/Gambling-commision.png" width="10%" height="10%" >
        <img src="aman/GLI.png" width="10%" height="10%" >
        <img src="aman/MGA.png" width="10%" height="10%" >
        <img src="aman/pagcor.png" width="10%" height="10%" >
    </p>
    <p>
        <img src="tanggungjawab/18+.png" width="5%" height="5%" >
        <img src="tanggungjawab/Begamble.png" width="5%" height="5%" >
        <img src="tanggungjawab/Gamcare.png" width="5%" height="5%" >
        <img src="tanggungjawab/GT.png" width="5%" height="5%" >
        
    </p>
</center>





</body>





</html>